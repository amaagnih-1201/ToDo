package com.cucumber.pages;

import java.util.List;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.cucumber.base.BaseTest;

import io.cucumber.datatable.DataTable;

public class TitlePage extends BaseTest {
	
	public TitlePage(){
		PageFactory.initElements(driver, this);
	}
	WebDriverWait wait = new WebDriverWait(driver,30);
	
	@FindBy(xpath="//input[@class='new-todo']")
	WebElement addTask;
	
	@FindBy(xpath="//label[text()='task']//preceding::input[1]")
	WebElement selectTask;
	
	@FindBy(xpath="//button[@class='clear-completed']")
	WebElement deleteTask;
	
	public String getTitle(){
		return driver.getTitle();
	}
	
	public void addTask(DataTable tasks){
		List<List<String>> tasklist= tasks.cells();
		wait.until(ExpectedConditions.visibilityOf(addTask));
		for(int i=0; i<tasklist.size();i++) {
			addTask.sendKeys(tasklist.get(i).get(0));
			addTask.sendKeys(Keys.ENTER);
		}
		/*
		 * addTask.sendKeys(tasklist.get(0).get(0)); addTask.sendKeys(Keys.ENTER);
		 * addTask.sendKeys(tasklist.get(1).get(0)); addTask.sendKeys(Keys.ENTER);
		 * addTask.sendKeys(tasklist.get(2).get(0)); addTask.sendKeys(Keys.ENTER);
		 */
		
		}
	public void completeTask(){
		selectTask.click();
		
		}
	public void deletecompleteTask() {
		deleteTask.click();
	}
}