package com.cucumber.stepdefinitions;


import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.cucumber.base.BaseTest;
import com.cucumber.pages.TitlePage;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;


public class TitlePageSteps extends BaseTest {
	
	
@Before
public void openBrowser(){
	BaseTest.initBrowser();
}

/*
 * @After public void tearDown(){ driver.close(); }
 */

TitlePage titlePage;


@SuppressWarnings("deprecation")
@Given("User is on todos Page")
public void user_is_on_todos_Page() {
	
	String URL = prop.getProperty("ApplicationURL");
	driver.get(URL);  
	titlePage =  new TitlePage();
}

@Given("User verify he is on Todo Page")
public void user_verify_he_is_on_Todo_Page() {

    String expectedTitle = "React � TodoMVC";
    Assert.assertEquals(expectedTitle, titlePage.getTitle());
}

@Then("User enter his tasks")
public void user_enter_his_tasks(DataTable dataTable) {
	titlePage.addTask(dataTable);
}

@Then("User select the task which is completed")
public void user_select_the_task_which_is_completed() {
    titlePage.completeTask();
    
}

@Then("User clear the completed task")
public void user_clear_the_completed_task() {
	titlePage.deletecompleteTask();
}

}
